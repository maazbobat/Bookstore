﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MaazBobat_Bookstore
{
    public partial class Products : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Retrieve user's first name from session
                if (Session["FirstName"] != null)
                {
                    lblWelcome.Text = "Welcome Back, " + Session["FirstName"].ToString() + "!";
                }

                BindGenreDropdown();
                BindProductData();
            }
        }

        // Method to populate the Genre Dropdown from DB
        private void BindGenreDropdown()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["BookStoreDB"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT GenreID, GenreName FROM Genre";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    ddlGenres.DataSource = reader;
                    ddlGenres.DataTextField = "GenreName";
                    ddlGenres.DataValueField = "GenreID";
                    ddlGenres.DataBind();

                    // Insert default item
                    ddlGenres.Items.Insert(0, new ListItem("Select Genre", "0"));
                }
            }
        }

        protected void rptProducts_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                var bookTitle = DataBinder.Eval(e.Item.DataItem, "Title").ToString();
                var btnAddToCart = (Button)e.Item.FindControl("btnAddToCart");
                btnAddToCart.Attributes.Add("aria-label", $"Add {bookTitle} to cart");
            }
        }


        // Method to load products based on selected genre
        protected void ddlGenres_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindProductData();
        }

        private void BindProductData()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["BookStoreDB"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT BookID, Title, Author, Price FROM Books";
                if (ddlGenres.SelectedValue != "0")
                {
                    query += " WHERE GenreID = @GenreID";
                }

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    if (ddlGenres.SelectedValue != "0")
                    {
                        command.Parameters.AddWithValue("@GenreID", ddlGenres.SelectedValue);
                    }

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    rptProducts.DataSource = reader;
                    rptProducts.DataBind();
                }
            }
        }

        // Method to add item to cart
        protected void btnAddToCart_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            int bookId = Convert.ToInt32(btn.CommandArgument);

            // Find the RepeaterItem to get the quantity TextBox
            RepeaterItem item = (RepeaterItem)btn.NamingContainer;
            TextBox txtQuantity = (TextBox)item.FindControl("txtQuantity");

            if (int.TryParse(txtQuantity.Text, out int quantity) && quantity > 0)
            {
                AddToCart(bookId, quantity);
                Response.Write("<script>alert('Book added to cart!');</script>");
            }
            else
            {
                Response.Write("<script>alert('Please enter a valid quantity.');</script>");
            }
        }

        private void AddToCart(int bookId, int quantity)
        {
            // Here you would typically check and add the item to the cart in a session or database
            List<CartItem> cart = Session["Cart"] as List<CartItem> ?? new List<CartItem>();

            // Fetch book details from DB
            Book book = GetBookDetails(bookId);

            if (book != null)
            {
                CartItem existingItem = cart.Find(item => item.BookID == book.BookID);

                if (existingItem != null)
                {
                    existingItem.Quantity += quantity;
                    existingItem.TotalPrice = existingItem.Quantity * existingItem.Price;
                }
                else
                {
                    cart.Add(new CartItem
                    {
                        BookID = book.BookID,
                        Title = book.Title,
                        Price = book.Price,
                        Quantity = quantity,
                        TotalPrice = book.Price * quantity
                    });
                }

                Session["Cart"] = cart; // Store the updated cart in session
            }
            else
            {
                // Handle case where book details could not be fetched
                Response.Write("<script>alert('Unable to add book to cart. Book not found.');</script>");
            }
        }

        // Method to get book details from the database based on bookId
        private Book GetBookDetails(int bookId)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["BookStoreDB"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT BookID, Title, Author, Price FROM Books WHERE BookID = @BookID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@BookID", bookId);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        return new Book
                        {
                            BookID = (int)reader["BookID"],
                            Title = reader["Title"].ToString(),
                            Author = reader["Author"].ToString(),
                            Price = (decimal)reader["Price"]
                        };
                    }
                }
            }
            return null; // Return null if the book is not found
        }
    }

    // Define the Book class
    public class Book
    {
        public int BookID { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public decimal Price { get; set; }
    }

    // Define the CartItem class
    public class CartItem
    {
        public int BookID { get; set; }
        public string Title { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public decimal TotalPrice { get; set; }
    }
}
