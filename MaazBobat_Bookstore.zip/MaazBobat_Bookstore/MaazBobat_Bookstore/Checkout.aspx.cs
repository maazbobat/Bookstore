﻿using System;
using System.Web.UI;

namespace MaazBobat_Bookstore
{
    public partial class Checkout : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // This code runs when the page is loaded
            if (!IsPostBack)
            {
                // Any initialization can be done here
            }
        }

        // Event handler for the "Place Order" button
        protected void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            try
            {
                // Perform validation, process the order, and clear the form/cart
                if (Page.IsValid)
                {
                    // Simulate placing an order
                    PlaceOrder();

                    // Show success message
                    lblMessage.Text = "Order Placed!";
                    lblMessage.ForeColor = System.Drawing.Color.Green; // Ensure it's green for success

                    // Clear the cart (for example, clear session data if the cart is stored in session)
                    Session["Cart"] = null;

                    // Clear the form inputs
                    ClearForm();
                }
            }
            catch (Exception ex) // Catch any generic exception
            {
                // Handle any errors that occurred during the order process
                lblMessage.Text = "An error occurred while placing your order. Please try again.";
                lblMessage.ForeColor = System.Drawing.Color.Red;

                // Log the exception (optional, depends on your logging strategy)
                // You can log the error message, stack trace, etc.
                // For example: LogError(ex);
            }
        }

        // Event handler for the "Go back to Cart" button
        protected void btnGoBackToCart_Click(object sender, EventArgs e)
        {
            // Redirect the user back to the cart page
            Response.Redirect("Cart.aspx");
        }

        // This method simulates placing an order
        private void PlaceOrder()
        {
            // This is where you would normally place your order processing logic
            // Example: Saving order details to the database
            // Try-catch ensures that any issues in this logic are handled

            // Simulating an order process for demonstration
            try
            {
                // Code for order placement goes here
                // Example: SaveOrderToDatabase(); // This can throw an exception
            }
            catch (Exception ex)
            {
                // Handle any order processing-specific errors here
                throw new Exception("Order processing failed.", ex);
            }
        }

        // This method clears the form inputs after an order is placed
        private void ClearForm()
        {
            txtEmail.Text = "";
            txtConfirmEmail.Text = "";
            txtPhone.Text = "";
            txtAddress.Text = "";
            txtCity.Text = "";
            ddlState.SelectedIndex = 0;
            txtPostalCode.Text = "";
            txtDOB.Text = "";
        }
    }
}
