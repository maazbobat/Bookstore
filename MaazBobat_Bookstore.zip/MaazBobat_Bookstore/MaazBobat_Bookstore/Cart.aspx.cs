﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MaazBobat_Bookstore
{
    public partial class Cart : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindCartData();
            }
        }

        private decimal GetTotalAmount()
        {
            List<CartItem> cart = Session["Cart"] as List<CartItem>;
            if (cart != null)
            {
                decimal total = 0;
                foreach (var item in cart)
                {
                    total += item.TotalPrice;
                }
                return total;
            }
            return 0; // Return 0 if cart is empty
        }

        private void BindCartData()
        {
            // Retrieve the cart from session
            List<CartItem> cart = Session["Cart"] as List<CartItem>;

            if (cart != null && cart.Count > 0)
            {
                rptCartItems.DataSource = cart;
                rptCartItems.DataBind();

                // Calculate total amount
                decimal totalAmount = GetTotalAmount();
                lblTotalAmount.Text = totalAmount.ToString("C2"); // Format as currency

                // Find the footer total label
                Label footerLabel = (Label)rptCartItems.Controls[0].FindControl("lblFooterTotal");
                if (footerLabel != null)
                {
                    footerLabel.Text = totalAmount.ToString("C2");
                }
            }
            else
            {
                // No items in cart, display a message
                lblTotalAmount.Text = "$0.00"; // Show zero amount
                lblCartMessage.Text = "Your cart is empty! Please add items to your cart.";
                lblCartMessage.Visible = true; // Show a message if cart is empty
            }
        }

        protected void btnCheckout_Click(object sender, EventArgs e)
        {
            // Redirect to the checkout page
            Response.Redirect("Checkout.aspx");
        }

        protected void rptCartItems_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Footer)
            {
                Label footerLabel = (Label)e.Item.FindControl("lblFooterTotal");
                if (footerLabel != null)
                {
                    footerLabel.Text = GetTotalAmount().ToString("C2");
                }
            }
        }

        protected void btnRemove_Click(object sender, EventArgs e)
        {
            Button btnRemove = (Button)sender;
            int bookId = Convert.ToInt32(btnRemove.CommandArgument); // Get BookID from CommandArgument

            // Remove item from cart
            RemoveFromCart(bookId);

            // Re-bind cart data to reflect changes
            BindCartData();
        }

        private void RemoveFromCart(int bookId)
        {
            List<CartItem> cart = Session["Cart"] as List<CartItem>;

            if (cart != null)
            {
                // Find the item to remove
                CartItem itemToRemove = cart.Find(item => item.BookID == bookId);
                if (itemToRemove != null)
                {
                    cart.Remove(itemToRemove); // Remove the item from the cart
                }

                // Update session
                Session["Cart"] = cart; // Save updated cart back to session
            }
        }

        protected void btnContinueShopping_Click(object sender, EventArgs e)
        {
            // Redirect to the products page or wherever you'd like
            Response.Redirect("Products.aspx");
        }
    }
}
