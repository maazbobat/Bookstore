﻿using System;

namespace MaazBobat_Bookstore
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            // Store the first name in a session or cookie
            string firstName = txtFirstName.Text.Trim();
            string lastName = txtLastName.Text.Trim();

            if (!string.IsNullOrEmpty(firstName) && !string.IsNullOrEmpty(lastName))
            {
                // Storing the user's first name in session
                Session["FirstName"] = firstName;
                Session["LastName"] = lastName;

                // Redirect to the products page
                Response.Redirect("Products.aspx");
            }
            else
            {
                // Show error message if fields are empty (optional)
                // lblErrorMessage.Text = "Please enter both first name and last name.";
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            // Redirect to homepage or any other page
            Response.Redirect("Home.aspx");
        }
    }
}
